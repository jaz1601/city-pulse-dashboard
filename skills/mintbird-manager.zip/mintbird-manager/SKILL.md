---
name: mintbird-manager
description: "Manage sales funnels, products, and checkouts on app.mintbird.com. Use for: creating/editing funnels, managing digital products, setting up checkouts, and tracking sales."
version: 1.0.0
author: Denise
---

# MintBird Manager Skill

This skill provides comprehensive management of sales funnels, products, and checkouts on the MintBird platform via the PopLinks API.

## Overview

MintBird (PopLinks) is a platform for creating sales funnels, lead pages, and digital product checkouts. This skill enables AI agents to:

- **Product Management**: Create, update, delete, and list digital products
- **Funnel Management**: Create and manage sales funnels with upsell/downsell flows
- **Lead Page Management**: Create and manage lead capture pages
- **Checkout Configuration**: Set up checkout templates and payment processing
- **Order Tracking**: Retrieve sales data and customer information
- **Analytics**: Track page views, conversions, and revenue

## Authentication

### API Key Setup

The skill uses Bearer token authentication with your MintBird API key.

**Environment Variable (Recommended):**
```bash
export MINTBIRD_API_KEY="your_api_key_here"
```

**Direct Usage:**
Pass the API key directly to scripts using the `--api-key` flag.

### Getting Your API Key

1. Log into your MintBird account at https://app.mintbird.com
2. Navigate to Settings → API Keys
3. Generate a new API key
4. Copy and store securely

## API Base URL

```
https://api.poplinks.io/api/ai
```

## Core Workflows

### 1. Product Management

#### List All Products
```bash
python scripts/list_products.py
```

#### Create a New Product
```bash
python scripts/create_product.py \
  --name "Digital Income Starter Kit" \
  --price 49.00 \
  --type digital \
  --description "Complete guide to building digital income streams"
```

#### Update Product
```bash
python scripts/update_product.py \
  --product-id 12345 \
  --price 59.00 \
  --status active
```

#### Delete Product
```bash
python scripts/delete_product.py --product-id 12345
```

### 2. Lead Page Management

#### List All Lead Pages
```bash
python scripts/list_lead_pages.py
```

#### Create Lead Page
```bash
python scripts/create_lead_page.py \
  --name "Free Guide Opt-in" \
  --category-id 1919 \
  --template-id 1
```

#### Get Lead Page Details
```bash
python scripts/get_lead_page.py --page-id 14310
```

#### Update Lead Page
```bash
python scripts/update_lead_page.py \
  --page-id 14310 \
  --title "Updated Headline" \
  --content "New body content"
```

#### Delete Lead Page
```bash
python scripts/delete_lead_page.py --page-id 14310
```

### 3. Funnel Management

#### List All Funnels
```bash
python scripts/list_funnels.py
```

#### Create Sales Funnel
```bash
python scripts/create_funnel.py \
  --name "Main Product Funnel" \
  --product-id 1745 \
  --upsell-product-id 1746 \
  --downsell-product-id 1747
```

#### Get Funnel Analytics
```bash
python scripts/get_funnel_stats.py --funnel-id 123
```

### 4. Order & Sales Tracking

#### List Recent Orders
```bash
python scripts/list_orders.py --limit 50
```

#### Get Order Details
```bash
python scripts/get_order.py --order-id 98765
```

#### Get Sales Summary
```bash
python scripts/get_sales_summary.py --start-date 2026-03-01 --end-date 2026-03-12
```

### 5. Category Management

#### List Categories
```bash
python scripts/list_categories.py
```

#### Create Category
```bash
python scripts/create_category.py --name "Digital Products"
```

## Data Schemas

See `references/schemas.md` for complete object definitions:

- **Product Object**: id, name, price, type, status, etc.
- **LeadPage Object**: id, name, views, leads, template, etc.
- **Funnel Object**: id, name, steps, conversion rates, etc.
- **Order Object**: id, customer, products, total, status, etc.
- **Category Object**: id, name, type, domain association

## Error Handling

All scripts include comprehensive error handling:

- **401 Unauthorized**: Invalid or expired API key
- **404 Not Found**: Resource doesn't exist
- **422 Validation Error**: Invalid data provided
- **429 Rate Limited**: Too many requests
- **500 Server Error**: MintBird server issue

### Common Error Responses

```json
{
  "status": false,
  "message": "Error description",
  "errors": {
    "field": ["error details"]
  }
}
```

## Best Practices

1. **Always test in sandbox first** when available
2. **Use categories** to organize products and pages
3. **Track analytics** regularly to optimize funnels
4. **Backup configurations** before major changes
5. **Monitor rate limits** - implement retries with backoff

## Rate Limiting

- Default: 100 requests per minute
- Burst: 10 requests per second
- Scripts include automatic retry logic

## Security Notes

- Never commit API keys to version control
- Use environment variables for sensitive data
- Rotate API keys regularly
- Monitor API usage for unauthorized access

## Troubleshooting

### API Key Not Working
- Verify key is active in MintBird dashboard
- Check for extra spaces or characters
- Ensure proper Bearer token format

### Pages Not Showing
- Verify correct category ID
- Check page status (active vs inactive)
- Confirm user permissions

### Orders Missing
- Check date range parameters
- Verify timezone settings
- Confirm order status filters

## Support

For API issues:
1. Check MintBird status page
2. Review API documentation
3. Contact MintBird support with error details

## Changelog

### v1.0.0
- Initial release
- Product management
- Lead page management
- Funnel operations
- Order tracking
- Category management
